package com.jsp.hospital_management_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.hospital_management_system.dto.Hospital;
import com.jsp.hospital_management_system.service.Hospitalservice;

@RestController
public class Hospitalcontroller {

	@Autowired
	private Hospitalservice hospitalservice;
	
	@PostMapping("/savehospital")
	public Hospital saveHospital(@RequestBody Hospital hospital) {
		return hospitalservice.saveHospital(hospital);
		
	}
	@PutMapping("/updatehospital")
	public Hospital updateHospital(@RequestParam int id,@RequestBody Hospital hospital) {
		return hospitalservice.updateHospital(id, hospital);
	}
	
	@DeleteMapping("/deletehospital")
	public Hospital deleteHospital(@RequestParam int id) {
		return hospitalservice.deleteHospital(id);
	}
	
	@GetMapping("/gethospitalbyid")
	public Hospital getHospitalbyid(@RequestParam int id) {
		return hospitalservice.getHospitalbyid(id);
	}
}
