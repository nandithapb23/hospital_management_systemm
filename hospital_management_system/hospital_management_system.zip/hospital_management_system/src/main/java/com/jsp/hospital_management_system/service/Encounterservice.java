package com.jsp.hospital_management_system.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jsp.hospital_management_system.dao.Branchdao;
import com.jsp.hospital_management_system.dao.Encounterdao;
import com.jsp.hospital_management_system.dao.Persondao;
import com.jsp.hospital_management_system.dto.Branch;
import com.jsp.hospital_management_system.dto.Encounter;
import com.jsp.hospital_management_system.dto.Person;

@Service
public class Encounterservice {

	@Autowired
	private Encounterdao encounterdao;
	
	@Autowired
	private Persondao persondao;
	
	@Autowired
	private Branchdao branchdao;
	
	public Encounter saveEncounter(Encounter encounter,int pid,int bid) {
		Person person=persondao.getPersonbyid(pid);
		Branch branch=branchdao.getbranchbyid(bid);
		
		encounter.setPerson(person);
		List<Branch> list=new ArrayList<>();
		list.add(branch);
		encounter.setBranchs(list);
		
		Encounter dbEncounter=encounterdao.saveEncounter(encounter);
		return dbEncounter;
		
	}
	public Encounter updateEncounter(int id,Encounter encounter,int bid) {
		Encounter dbEncounter=encounterdao.getEncounterbyid(id);
		Branch branch=branchdao.getbranchbyid(bid);
		
		List<Branch> list=dbEncounter.getBranchs();
		encounter.setBranchs(dbEncounter.getBranchs());
		encounter.setPerson(dbEncounter.getPerson());
		
		Encounter encounter2=encounterdao.updatEncounter(id, encounter);
		return encounter2;
		
	}
	
	public Encounter deletEncounter(int id) {
		Encounter encounter=encounterdao.deletEncounter(id);
		if(encounter!=null) {
			return encounter;
		}else {
			return null;
		}
		
	}
	public Encounter getEncounterbyid(int id) {
		Encounter encounter=encounterdao.getEncounterbyid(id);
		if(encounter!=null) {
			return encounter;
		}else {
			return null;
		}
		
	}
}
