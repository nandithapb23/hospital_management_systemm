package com.jsp.hospital_management_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jsp.hospital_management_system.dao.Hospitaldao;
import com.jsp.hospital_management_system.dto.Hospital;

@Service
public class Hospitalservice {

	@Autowired
	private Hospitaldao hospitaldao;
	
	public Hospital saveHospital(Hospital hospital) {
		return hospitaldao.saveHospital(hospital);
		
	}
	public Hospital updateHospital(int id,Hospital hospital) {
		Hospital dbHospital=hospitaldao.updateHospital(id, hospital);
		if(dbHospital!=null) {
			return dbHospital;
		}else {
			return null;
		}
		
	}
	public Hospital deleteHospital(int id) {
		Hospital hospital=hospitaldao.deleteHospital(id);
		if(hospital!=null) {
			return hospital;
		}else {
			return null;
		}
		
	}
	public Hospital getHospitalbyid(int id) {
		Hospital hospital=hospitaldao.getHospitalbyid(id);
		if(hospital!=null) {
			return hospital;
		}else {
			return null;
		}
		
	}
}
